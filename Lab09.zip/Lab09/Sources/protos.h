//********
// Kobe Liles
// lab09
// 3/5/2024
//********


//prototypes
void TaskScheduler(void);
void ECTInitialize(void);
void IntializePorts(void);
void BitZero(void);
void BitOne(void);
void BitTwo(void);
void interrupt MyInterrupt(void);
void Motor(void);
void Speed(void);
