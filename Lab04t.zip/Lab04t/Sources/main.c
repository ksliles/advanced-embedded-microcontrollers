#include <hidef.h>      /* common defines and macros */
//#include "derivative.h"      /* derivative-specific definitions */
#include "ports.h"
#include "defs.h"
#include "protos.h"

//********
// Kobe Liles
// lab04
// 1/30/2024
//********



void main(void) 
{
  /* put your own code here */ 
DDRC = 0xff; //set LEDS to outputs
DDRB = 0x00; //set switches to inputs




  for(;;) 
  {
  
    //traditional();
    Modern();
    
    _FEED_COP(); /* feeds the dog */
  } /* loop forever */
  /* please make sure that you never leave main */
}
/*
void Traditional(void)
{
    if(PORTB & BIT_0) // test: is switch 0 high?
    {
       PORTC |= BIT_7; // if switch 0 is high, set LED bit 7
    }
    else
    {
       PORTC &= ~BIT_7; //if switch 0 is low, clear LED bit 7
    }
    
    if(PORTB & BIT_1) // test: is switch 1 high?
    {
       PORTC |= BIT_6; // if switch 1 is high, set LED bit 6
    }
    else
    {
       PORTC &= ~BIT_6; //if switch 1 is low, clear LED bit 6
    }
    
    if(PORTB & BIT_2) // test: is switch 2 high?
    {
       PORTC |= BIT_5; // if switch 2 is high, set LED bit 5
    }
    else
    {
       PORTC &= ~BIT_5; //if switch 2 is low, clear LED bit 5
    }
    
    if(PORTB & BIT_3) // test: is switch 3 high?
    {
       PORTC |= BIT_4; // if switch 3 is high, set LED bit 4
    }
    else
    {
       PORTC &= ~BIT_4; //if switch 3 is low, clear LED bit 4
    }
    
    if(PORTB & BIT_4) // test: is switch 4 high?
    {
       PORTC |= BIT_3; // if switch 4 is high, set LED bit 3
    }
    else
    {
       PORTC &= ~BIT_3; //if switch 4 is low, clear LED bit 3
    }
    
    if(PORTB & BIT_5) // test: is switch 5 high?
    {
       PORTC |= BIT_2; // if switch 5 is high, set LED bit 2
    }
    else
    {
       PORTC &= ~BIT_2; //if switch 5 is low, clear LED bit 2
    }
    
    if(PORTB & BIT_6) // test: is switch 6 high?
    {
       PORTC |= BIT_1; // if switch 6 is high, set LED bit 1
    }
    else
    {
       PORTC &= ~BIT_1; //if switch 6 is low, clear LED bit 1
    }
    
    if(PORTB & BIT_7) // test: is switch 7 high?
    {
       PORTC |= BIT_0; // if switch 7 is high, set LED bit 0
    }
    else
    {
       PORTC &= ~BIT_0; //if switch 7 is low, clear LED bit 0
    }
    
}
*/
void Modern(void)
{

  if(PORT_B.BIT_0) // test: is switch 0 high?
    {
       PORT_C.BIT_7 = 1; // if switch 0 is high, set LED bit 7
    }
    else
    {
       PORT_C.BIT_7 = 0; //if switch 0 is low, clear LED bit 7
    }
    
    if(PORT_B.BIT_1) // test: is switch 1 high?
    {
       PORT_C.BIT_6 = 1; // if switch 1 is high, set LED bit 6
    }
    else
    {
       PORT_C.BIT_6 = 0; //if switch 1 is low, clear LED bit 6
    }
    
    if(PORT_B.BIT_2) // test: is switch 2 high?
    {
       PORT_C.BIT_5 = 1; // if switch 2 is high, set LED bit 5
    }
    else
    {
       PORT_C.BIT_5 = 0; //if switch 2 is low, clear LED bit 5
    }
    
    if(PORT_B.BIT_3) // test: is switch 3 high?
    {
       PORT_C.BIT_4 = 1; // if switch 3 is high, set LED bit 4
    }
    else
    {
       PORT_C.BIT_4 = 0; //if switch 3 is low, clear LED bit 4
    }
    
    if(PORT_B.BIT_4) // test: is switch 4 high?
    {
       PORT_C.BIT_3 = 1; // if switch 4 is high, set LED bit 3
    }
    else
    {
       PORT_C.BIT_3 = 0; //if switch 4 is low, clear LED bit 3
    }
    
    if(PORT_B.BIT_5) // test: is switch 5 high?
    {
       PORT_C.BIT_2 = 1; // if switch 5 is high, set LED bit 2
    }
    else
    {
       PORT_C.BIT_2 = 0; //if switch 5 is low, clear LED bit 2
    }
    
    if(PORT_B.BIT_6) // test: is switch 6 high?
    {
       PORT_C.BIT_1 = 1; // if switch 6 is high, set LED bit 1
    }
    else
    {
       PORT_C.BIT_1 = 0; //if switch 6 is low, clear LED bit 1
    }
    
    if(PORT_B.BIT_7) // test: is switch 7 high?
    {
       PORT_C.BIT_0 = 1; // if switch 7 is high, set LED bit 0
    }
    else
    {
       PORT_C.BIT_0 = 0; //if switch 7 is low, clear LED bit 0
    }    
  
}
