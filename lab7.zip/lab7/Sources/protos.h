//********
// Kobe Liles
// lab07
// 2/20/2024
//********

//protos
void InitializePorts(void);
void InitializeDisplay(void);
void WriteCommands(unsigned char);
void Delay(unsigned long);
void SendString(char*);
void LCD_busy(void);
void BackLight(unsigned char);
