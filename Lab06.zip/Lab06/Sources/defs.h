//********
// Kobe Liles
// lab05
// 1/30/2024
//********






//define bits
#define BIT0 0x01
#define BIT1 0x02
#define BIT2 0x04
#define BIT3 0x08
#define BIT4 0x10
#define BIT5 0x20
#define BIT6 0x40
#define BIT7 0x80


//macros 
#define LCD_RS_ON   (PORTD |= BIT5)
#define LCD_RS_OFF   (PORTD &= ~BIT5)
#define LCD_RW_ON   (PORTD |= BIT6)
#define LCD_RW_OFF   (PORTD &= ~BIT6)
#define LCD_EN_ON   (PORTD |= BIT7)
#define LCD_EN_OFF   (PORTD &= ~BIT7)
 