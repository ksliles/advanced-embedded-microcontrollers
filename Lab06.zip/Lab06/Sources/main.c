#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "protos.h"
#include "defs.h"
//********
// Kobe Liles
// lab05
// 1/30/2024
//********




void main(void) 
{
  /* put your own code here */
  
 InitializePorts();
 InitializeDisplay();
 SendString("Hello World");

  for(;;) 
  {
    _FEED_COP(); /* feeds the dog */
  } /* loop forever */
  /* please make sure that you never leave main */
}
