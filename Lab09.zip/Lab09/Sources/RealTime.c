#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "protos.h"
#include "defs.h"
//********
// Kobe Liles
// lab09
// 3/5/2024
//********
volatile unsigned int MSecTime2 = 0;
volatile unsigned int MSecTime5 = 0;
volatile unsigned int MSecTime40 = 0;

void ECTInitialize(void)
{
  ECT_TIOS_IOS0 = 1;
  ECT_TIOS_IOS1 = 1;
  ECT_TIOS_IOS2 = 1;
  ENABLE_INT; // Global interrupts on
  
}

void RTIInitilize()
{
  CRGINT =0x80; 
  CRGINT_RTIE = 1; // CRT: clocks and reset generators
  RTICTL = 0x70; // interrupt will happen every 4.096 ms
  ENABLE_INT; // Global interrupts on
}

void interrupt RTISer()
{

    CRGFLG = BIT7;//clear flag (write 1 to flag bit to clear)
    MSecTime++;// increment a counter (a very volatile global variable)
}

void RTIDelay()
{
  MSecTime = 0;
  while(MSecTime < 122) //4.096ms * 250 = ~ 1.024s
  {
    ; // wait for the interrupt to happen 250 times
  }
}

