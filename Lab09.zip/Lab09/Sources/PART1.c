#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "protos.h"
#include "defs.h"

//********
// Kobe Liles
// lab09
// 3/5/2024
//********

//global variables
unsigned int fastSpeed;
unsigned int slowSpeed;
volatile unsigned int TwoMsDelayValue = 16000;
volatile unsigned int MSecTime2 = 0;
volatile unsigned int MSecTime5 = 0;
volatile unsigned int MSecTime40 = 0;
volatile unsigned int MSecTime100 = 0;
volatile unsigned int InterruptCounter = 0;

void ECTInitialize(void)
{
  ENABLE_INT; // Global interrupts on
  ECT_TSCR1_TEN = 1;
  ECT_TIOS_IOS1 =1;
  ECT_TIE_C1I = 1;
  ECT_TFLG1_C1F =1;
  ECT_TC1 = ECT_TCNT + 16000; //base speed
  ECT_TCTL2_OL1 = 1;
  ECT_TCTL2_OM1 = 0;
  
}

void interrupt MyInterrupt(void)
{
   //reset the flag
   ECT_TFLG1_C1F = 1;
   ECT_TC1 += TwoMsDelayValue;
   
   if(InterruptCounter%50 == 0)
   {
      MSecTime2++;//5hz
   }
   
   if(InterruptCounter%125 == 0)
   {
      MSecTime5++;//2hz
   }
   
   if(InterruptCounter%1000 == 0)
   {
      MSecTime40++;//0.25hz
   }
   if(InterruptCounter%2500 == 0)
   {
      MSecTime100++;//0.25hz
   }
   if(InterruptCounter >= 2500)
   {
      InterruptCounter = 0;
   }
   
   InterruptCounter++;   
}

void IntializePorts(void)
{
   DDRC = 0xff;
   DDRP = 0x01;
   DDRB = 0x00;
}

void BitZero(void)
{
   PORTC ^= 0x01; //toggle bit zero
}

void BitOne(void)
{
   PORTC ^= 0x02; //toggle bit one
}

void BitTwo(void)
{
   PORTC ^= 0x04; //toggle bit two
}

void Motor(void)
{
   static char intervalCount = 0;
   
   if(fastSpeed && (intervalCount < 9))
   {
      PTP = 0x01; //turn on motor
      intervalCount++;
   }
   else
   {
      PTP = 0x00; //turn off motor
      intervalCount = 0;
   }
   
   if(slowSpeed && (intervalCount < 3))
   {
      PTP = 0x01; //turn on motor
      intervalCount++;
   }
   else
   {
      PTP = 0x00; //turn off motor
      intervalCount = 0;
   }
   
}

void Speed(void)
{
   if(PORTB & 0x01)
   {
     fastSpeed = 1; //activate fast speed for motor
   }
   
   if(!(PORTB & 0x01))
   {
     slowSpeed = 1; //activte slow speed for motor
   }
}

void TaskScheduler(void)
{ 
  if (MSecTime2 > 0)
  { 
      MSecTime2--;
      BitZero();
  }
  if (MSecTime5 > 0)
  { 
      MSecTime5--;
      BitOne();
  }
  if (MSecTime40 > 0)
  { 
      MSecTime40--;
      BitTwo();
  }
  if (InterruptCounter > 0)
  {
      InterruptCounter--;
      Motor();
  }
  if (MSecTime100 > 0)
  {
      MSecTime100--;
      Speed();
  }
}