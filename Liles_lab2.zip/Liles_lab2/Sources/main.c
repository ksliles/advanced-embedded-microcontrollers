#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "protos.h"


//*******
// Kobe Liles
// 1/16/2024
// ECET 309
// Lab02
//*******




void main(void) 
{
  unsigned char call; //variable used for Keypad value
  unsigned char call1; //variable used for acsII value
  unsigned char val1 = 0xeb; //predetermined value

  call = keyPad(val1); // pass val1 into keypad, then set equal to call
  call1 = acsII(val1); //pass val1 into acsII, then set equal to call1

  for(;;) 
  {
   
   
    _FEED_COP(); /* feeds the dog */
  } /* loop forever */
  /* please make sure that you never leave main */
}
