//********
// Kobe Liles
// lab04
// 1/30/2024
//********


//void traditional(void);//protype for traditional function
void Modern(void); //prototype for modern function