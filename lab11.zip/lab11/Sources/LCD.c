#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "protos.h"
#include "defs.h"
#include <stdio.h>
//********
// Kobe Liles
// lab11
// 4/2/2024
//********

//values to set display to home/clear/second line
#define HOME_DISPLAY 0x02;
#define CLEAR_DISPLAY 0x01;
#define SECOND_LINE 0xc0;

unsigned char array[] = {0x30, 0x30, 0x30, 0x38, 0x0f, 0x01, 0x06};

//set registers bit to either inputs or outputs
void InitializePorts(void)
{
  DDRK = 0xff;
  DDRD = 0xE0;
  DDRE = 0x0C;
  DDRT = 0x40;
}

//loop through global array and subroutine the value to 
//writecommands
void InitializeDisplay(void)
{
   char i;
   for(i = 0; i < 7; i++)
   {
     WriteCommands(array[i]); 
   }
}

//read commands that are passed in
void WriteCommands(unsigned char var)
{
   PORTK = var;
   LCD_RS_OFF;
   LCD_RW_OFF;
   LCD_EN_ON;
   LCD_EN_OFF;
   Delay(20000);
  
}


void Delay(unsigned long count)
{
  int i;
  for(i = 0; i < count; i++)
  {
     ;
  }
}

//loop throguh character strirng passed in and display 
//onto the LCD screen. If value is over 16 character
//then use the second line on the LCD display.
void SendString(char *var)
{
   char i;   
   for(i = 0;i < *var; i++)
   {
      
      PORTK = *var++;
      LCD_RS_ON;
      LCD_RW_OFF;
      LCD_EN_ON;
      LCD_EN_OFF;
      Delay(20000);
      
      if(i == 16)
      {
        
         PORTK = HOME_DISPLAY;
         LCD_RS_OFF;
         LCD_RW_OFF;
         LCD_EN_ON;
         LCD_EN_OFF;
         Delay(20000);
         
         PORTK = SECOND_LINE;
         LCD_RS_OFF;
         LCD_RW_OFF;
         LCD_EN_ON;
         LCD_EN_OFF;        
       
      }
   }
   if(i < 16)
   {
         Delay(20000);
         PORTK = CLEAR_DISPLAY;
         LCD_RS_OFF;
         LCD_RW_OFF;
         LCD_EN_ON;
         LCD_EN_OFF;
   }
}

//slows down the time(similar to delay).
void LCD_busy(void)
{
  LCD_DDR_D7_OFF;  
  LCD_RS_OFF;
  LCD_RW_ON;
  LCD_EN_ON;
  
  while(LCD_D7)
  {
    LCD_EN_OFF;
    LCD_EN_ON;
  }
  LCD_DDR_D7_ON;
}

//bring in predifned value from a subroutine and
//setting PORTE to whichever value was sent to
//set the color of the blacklight.
void BackLight(unsigned char var)
{
  PORTE = var;
}




