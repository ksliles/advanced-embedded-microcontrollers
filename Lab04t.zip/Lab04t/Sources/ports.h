//********
// Kobe Liles
// lab04
// 1/30/2024
//********


#define PORTB (*(volatile unsigned char*)(0x01))//set PORTB to address 1
#define PORTC (*(volatile unsigned char*)(0x04))//set PORTC to address 4
#define DDRC (*(volatile unsigned char*)(0x06))//set DDRC to address 6
#define DDRB (*(volatile unsigned char*)(0x03))//set DDRB to address 3