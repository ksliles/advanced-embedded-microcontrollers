//*******
// Kobe Liles
// 1/16/2024
// ECET 309
// Lab02
//*******
unsigned char keyPad(unsigned char);  //prototype function for keypad
unsigned char acsII(unsigned char);   //prototype function for acsII
void Initialize(void);
void KeyWrite(unsigned char);
void delay(unsigned int);
void GetKeyPress(void);
void KeyRelease(unsigned char);