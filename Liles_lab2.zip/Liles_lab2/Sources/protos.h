//*******
// Kobe Liles
// 1/16/2024
// ECET 309
// Lab02
//*******
unsigned char keyPad(unsigned char);  //prototype function for keypad
unsigned char acsII(unsigned char);   //prototype function for acsII