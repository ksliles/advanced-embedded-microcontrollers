#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "protos.h"
#include "defs.h"
#include <stdio.h>
//********
// Kobe Liles
// lab11
// 4/2/2024
//********

volatile unsigned int sendSignal;
volatile unsigned int receiveSignal;
volatile unsigned int rawCount;
volatile unsigned int fullCount;
volatile unsigned int speed;
volatile unsigned int distance;
volatile unsigned int feet;
volatile unsigned int inches;
           signed char buffer[50];

void main(void) 
{
  
  InitializePorts();
  InitializeDisplay();
  InitiliazeTimer();
  BackLight(DISPLAY_RED);

  for(;;) 
  {
     
     PTT_PTT6 = 0;
     
     
     while(PTS_PTS4)
     {
        ;
     }
     
     Delay(20);
     
     while(!(PTS_PTS4))
     {
        ;
     }
     
     SonarStart();
     SonarCheck();
     sprintf(buffer,"D = %d feet, %d inches", feet,inches);
     SendString(buffer);
     
  
    _FEED_COP(); 
  } 
  
}

void InitiliazeTimer(void)
{
  ECT_TSCR1_TEN = 1;
  ECT_TIOS |= 0xc0;
  ECT_TCTL3_EDG6A = 1;
  ECT_TCTL3_EDG6B = 0;
  ECT_TCTL3_EDG7A = 1;
  ECT_TCTL3_EDG7B = 0;
  ECT_TSCR2 = 0x03;
   
}

void SonarStart(void)
{
  ECT_TFLG1_C6F = 1;
  ECT_TFLG1_C7F = 1;
  PTT_PTT6 = 1; 
}

void SonarCheck(void)
{
  
  while(!(ECT_TFLG1_C7F))
  {
    ;
  }
  
  if(sendSignal > receiveSignal)
  {
      rawCount = ((65535 - sendSignal) + receiveSignal);
  }
  else
  {
      rawCount = receiveSignal - sendSignal;
  }    
}

void Conversion(void)
{
  fullCount = (1116 * 12);
  speed = (rawCount * 65) / 1000;
  distance  = fullCount * speed;
  
  feet = distance / 12;
  inches = distance % 12;
}