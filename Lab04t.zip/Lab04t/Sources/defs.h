//********
// Kobe Liles
// lab04
// 1/30/2024
//********

//define bits
//#define BIT_0 0x01
//#define BIT_1 0x02
//#define BIT_2 0x04
//#define BIT_3 0x08
//#define BIT_4 0x10
//#define BIT_5 0x20
//#define BIT_6 0x40
//#define BIT_7 0x80

//bitfield structure
struct bitField
{
    volatile unsigned char BIT_0 : 1;
    volatile unsigned char BIT_1 : 1;
    volatile unsigned char BIT_2 : 1;
    volatile unsigned char BIT_3 : 1;
    volatile unsigned char BIT_4 : 1;
    volatile unsigned char BIT_5 : 1;
    volatile unsigned char BIT_6 : 1;
    volatile unsigned char BIT_7 : 1;
};

//rename the structure as a datatype
typedef struct bitField BT;

//set bitfield as port address    
BT PORT_B@0x01;
BT PORT_C@0x04;