#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "protos.h"
//**********
// Kobe Liles
// 1/16/2024
// ECET 309
// Lab02
//**********

//gloabal variables
const unsigned char detectedKeyPress[] =  {0xd7, 0xee, 0xde, 0xbe,  //hardware values for PORTA
                                           0xed, 0xdd, 0xbd, 0xeb,
                                           0xdb, 0xbb, 0x7e, 0x7d,
                                           0x7b, 0x77, 0xe7, 0xb7};
                                           
const unsigned char keypadKeyPressValue[] = {0, 1, 2, 3,     //keypad values
                                             4, 5 ,6, 7,
                                             8, 9, 'A', 'B',
                                             'C', 'D', '*', '#'};
                                             
const unsigned char ASCIIvalue[] = {0x30, 0x31, 0x32, 0x33, //ansII value
                                    0x34, 0x35, 0x36, 0x37,
                                    0x38, 0x39, 0x41, 0x42,
                                    0x43, 0x44, 0x2A, 0x23};
                                    
                                    
                                    
                                    
unsigned char keyPad(unsigned char val1)
{
  unsigned char i; //variable for index
  for(i = 0; i < 16; i++)
  {
      if(val1 == detectedKeyPress[i]) //step thru array until index value equals predetmined value
      {
         return keypadKeyPressValue[i]; //return value if val1 = i
      }
  }
  return 0xff; //if vslue not found, return 0xff
}

unsigned char acsII(unsigned char val1)
{
  unsigned char j; //variable for index
  for(j = 0; j < 16; j++)
  {
      if(val1 == detectedKeyPress[j]) //step thru array until index value equals predetmined value
      {
         return ASCIIvalue[j]; //return value if val1 = j
      }
  }
  return 0xff; //if value not found, return 0xff
}
                                    
   
                                            
   