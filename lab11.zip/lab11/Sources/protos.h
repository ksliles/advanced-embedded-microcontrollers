//********
// Kobe Liles
// lab11
// 4/2/2024
//********



void InitializePorts(void);
void InitializeDisplay(void);
void WriteCommands(unsigned char);
void Delay(unsigned long);
void SendString(char*);
void LCD_busy(void);
void BackLight(unsigned char);
void InitiliazeTimer(void);
void SonarStart(void);
void SonarCheck(void);
void Conversion(void);