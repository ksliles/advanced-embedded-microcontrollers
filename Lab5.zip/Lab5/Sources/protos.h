//********
// Kobe Liles
// lab04
// 1/30/2024
//********

void Macros(void); //prototype for Macros