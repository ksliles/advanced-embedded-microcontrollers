#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "protos.h"
#include "defs.h"
//********
// Kobe Liles
// lab05
// 1/30/2024
//********

unsigned char array[] = {0x30, 0x30, 0x30, 0x38, 0x0f, 0x01, 0x06};

void InitializePorts(void)
{
  DDRK = 0xff;
  DDRD = 0xE0;
}

unsigned char InitializeDisplay(void)
{
   int i;
   for(i = 0; i < 7; i++)
   {
     WriteCommands(array[i]); 
   }
}

void WriteCommands(unsigned char var)
{
   PORTK = var;
   LCD_RS_OFF;
   LCD_RW_OFF;
   LCD_EN_ON;
   LCD_EN_OFF;
   Delay(20000);
  
}


void Delay(unsigned long count)
{
  int i;
  for(i = 0; i < count; i++)
  {
     ;
  }
}

void SendString(char *var)
{
   while(*var)
   {
       
      PORTK = *var++;
      LCD_RS_ON;
      LCD_RW_OFF;
      LCD_EN_ON;
      LCD_EN_OFF;
      Delay(20000);      
   }
}




