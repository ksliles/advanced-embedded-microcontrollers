//*********
// Kobe Liles
// Ecet 309
// 1/9/2024
// Lab 01
//*********

void FillTable(void);
int Fact(int);