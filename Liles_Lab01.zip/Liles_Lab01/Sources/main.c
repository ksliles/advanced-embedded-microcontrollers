#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "protos.h"



//*********
// Kobe Liles
// Ecet 309
// 1/9/2024
// Lab 01
//*********

unsigned char table[6]; //{1},{1},{2},{6},{24},{120}
//fact is called 16 times
void main(void) 
{
   
   FillTable();
  
  for(;;) 
  {
  
    
    _FEED_COP(); /* feeds the dog */
  } /* loop forever */
  /* please make sure that you never leave main */
}
void FillTable(void)
{
   int i;
   for (i = 0; i < 6; i++)
   {      
        table[i] = Fact(i);
   }
}
/* Recursive Factorial Function
*/
int Fact(int num)
{
   if (num < 2)
   {      
      return (1);
   }
   else
   {      
      return (num * Fact(num - 1));
   }
}
