#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "defs.h"
#include "protos.h"

//********
// Kobe Liles
// lab09
// 3/5/2024
//********

void main(void) 
{
  
  IntializePorts();
  ECTInitialize();

  for(;;) 
  {
  
    TaskScheduler(); //run the scheduler an infinite amount of times
  
    _FEED_COP(); /* feeds the dog */
  } /* loop forever */
  /* please make sure that you never leave main */
}
