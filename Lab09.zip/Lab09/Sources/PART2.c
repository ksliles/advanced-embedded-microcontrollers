#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "protos.h"
#include "defs.h"

//********
// Kobe Liles
// lab09
// 3/5/2024
//********

