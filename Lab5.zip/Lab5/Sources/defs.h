//********
// Kobe Liles
// lab04
// 1/30/2024
//********


//define bits
#define BITz 0x00
#define BIT0 0x01
#define BIT1 0x02
#define BIT2 0x04
#define BIT3 0x08
#define BIT4 0x10
#define BIT5 0x20
#define BIT6 0x40
#define BIT7 0x80
#define BITf 0xff

#define LED_ENABLED(n) DDRC |= BIT##n //make LED port bit an output
#define LED_ON(n) PORTC |= BIT##n//set LED bit high
#define LED_OFF(n) PORTC &= ~BIT##n //set LED bit low
#define SWITCH_STATE(n) PORTB & BIT##n//return true if high, false if low
#define SWITCH_ENABLED(n) DDRB |= BIT##n //make SWITCH port bit an output