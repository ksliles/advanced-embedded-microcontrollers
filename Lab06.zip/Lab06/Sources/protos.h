//********
// Kobe Liles
// lab05
// 1/30/2024
//********

//protos
void InitializePorts(void);
unsigned char InitializeDisplay(void);
void WriteCommands(unsigned char);
void Delay(unsigned long);
void SendString(char*);
